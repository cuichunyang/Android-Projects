package jp.ac.jec.cm0111.android114;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import java.util.ArrayList;

public class CardListActivity extends ListActivity {

    private ArrayList<String> ary = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_list);

        //TODO データベースから取得したデータを表示させる
        CardSQLiteOpenHelper helper = new CardSQLiteOpenHelper(this);
        helper.getAllCardTitle(ary);

        //ListViewに表示するデータを管理するためのアダプターを準備する
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, //アダプターを利用するActivityのコンテキスト
                android.R.layout.simple_list_item_1, //行レイアウトのリソースID(Androidで)
                ary //表示データの配列オブジェクト
        );
        //ListViewにアダプターをセットする(データが表示される)
        setListAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();

        CardSQLiteOpenHelper helper = new CardSQLiteOpenHelper(this);
        helper.getAllCardTitle(ary);
        ((ArrayAdapter<String>)getListAdapter()).notifyDataSetChanged(); //最新のアダプターの情報で
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        CardSQLiteOpenHelper helper = new CardSQLiteOpenHelper(this);
        String eng = (String) l.getItemAtPosition(position);

        //選択された英単語のidを取得する為に、英単語情報をデータベースより取得する
        Card tmp = helper.findCardByName(eng);
        Intent intent = new Intent(CardListActivity.this, EditActivity.class);

        //「編集モードでEditActivityを開く」という情報をintentに設定する
        intent.putExtra("mode", "update");

        //選択された英単語のidもintentに設定しておく
        intent.putExtra("id", tmp.getId());

        startActivity(intent);
            }


}
