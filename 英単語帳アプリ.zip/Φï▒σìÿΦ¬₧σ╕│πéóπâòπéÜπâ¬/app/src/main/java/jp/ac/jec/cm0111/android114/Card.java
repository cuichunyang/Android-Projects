package jp.ac.jec.cm0111.android114;

public class Card {
    private String japanese; //日本語
    private String english;  //英語
    private int id;//編集時に利用するデータのid

    public Card(String japanese, String english, int id){
        this.japanese = japanese;
        this.english = english;
        this.id = id;

    }



    public String getJapanese() {
        return japanese;
    }

    public String getEnglish() {
        return english;
    }

    public int getId() {
        return id;
    }
}
