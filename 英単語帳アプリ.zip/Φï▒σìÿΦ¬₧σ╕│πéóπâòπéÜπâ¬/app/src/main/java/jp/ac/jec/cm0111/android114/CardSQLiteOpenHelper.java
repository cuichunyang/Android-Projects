package jp.ac.jec.cm0111.android114;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;


public class CardSQLiteOpenHelper extends SQLiteOpenHelper {

    public CardSQLiteOpenHelper(Context context) {
        super(context, "CARD_DB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Androidアプリでは、作成するテーブルには「_id」の列(カラム)を用意しておくことが推奨される

        db.execSQL("CREATE TABLE CARD(_id INTEGER PRIMARY KEY AUTOINCREMENT, english TEXT, japanese TEXT)");
        db.execSQL("INSERT INTO CARD VALUES(1,'apple','リンゴ')");
        db.execSQL("INSERT INTO CARD VALUES(2,'banana','バナナ')");
        db.execSQL("INSERT INTO CARD VALUES(3,'lemon','レモン')");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public ArrayList<Card> getAllCard(){

        ArrayList<Card> ary = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();
        if(db == null){
            return null;
        }

        try{
            String[] column = new String[]{"japanese", "english" , "_id"}; //取得したいデータの列(カラム)名
            Cursor cur = db.query("CARD", //テーブル名
                     column,                    //取得する列名の名前
                    null,               //選択条件 "japanese like ?"
                    null,           //選択条件の?を置換する文字列の配列　例: "banana%"
                    null,               //集計条件
                    null,               //選択条件
                    null);              //ソート条件　例: "_id DESC"

            while(cur.moveToNext()){        //取得データの次の行へ移動する
                Card tmp = new Card(cur.getString(0),cur.getString(1),cur.getInt(2));
                ary.add(tmp);
            }
            cur.close();

        }finally{
           db.close();
        }

        return ary;
    }

    public boolean insertCard(Card newCard){
        long ret;
        SQLiteDatabase db = getWritableDatabase();
        try{
            ContentValues values = new ContentValues();
            values.put("english", newCard.getEnglish());
            values.put("japanese", newCard.getJapanese());
            ret = db.insert("CARD", null, values);
            //登録成功ならretにはデータのインデックスが入る。エラーなら-1が入る

        }finally {
            db.close();
        }

        return ret != -1; //成功:TRUE /失敗: FALSE
    }


    /**
     * デーブルの中にすでに同じ英語が登録されていないかチェックするメソッド
     * (重複チェック)
     * @param english
     * @return false:重複なし, true:重複あり
     */
    public boolean isExistWord(String english) {
        boolean ret = false;
        SQLiteDatabase db = getReadableDatabase();
        try {
            String[] column = new String[]{"japanese", "english", "_id"};
            Cursor cur = db.query("CARD",
                    null,
                    "english = ?",
                    new String[]{english},
                    null,
                    null,
                    null);

            if (cur.getCount() != 0) {
                ret = true;
            }
            cur.close();
        } finally {
            db.close();
        }
        return ret;
    }

    /**
     * englishカラムのデータのみ全権検索して取得するメソッド
     * @return
     */
    public void getAllCardTitle(ArrayList<String> ary) {
        //ArrayList<String> ary = new ArrayList<String>();

        ary.clear();

        SQLiteDatabase db = getReadableDatabase();
        if (db == null) {
            return;
        }

        try {
            Cursor cur = db.query("CARD", new String[]{"english"}, null, null, null, null, null);
            while (cur.moveToNext()) {
                ary.add(cur.getString(cur.getColumnIndex("english")));
            }
            cur.close();
        } finally {
            db.close();
        }

    }


    /**
     * 指定された英単語の情報を含む登録データのCardオブジェクトを取得する
     * @param english
     * @return
     */
    public Card findCardByName(String english) {

        Card tmp = null;
        SQLiteDatabase db = getReadableDatabase();

        try {
            String[] colomn = new String[]{"english", "japanese", "_id"};
            Cursor cur = db.query("CARD", colomn, "english = ?", new String[]{english},
                    null, null, null);

            if (cur.moveToNext()) {
                tmp = new Card(cur.getString(0), cur.getString(1), cur.getInt(2));
            }
            cur.close();

        } finally {
            db.close();

        }

        return tmp;

    }

    /**
     *  _id指定でデータを削除する
     * @param id
     */

    public void deleteCardById(int id){

        SQLiteDatabase db = getWritableDatabase();

        try{
            String sid = String.valueOf(id);
            long ret = db.delete("CARD","_id=?", new String[]{sid});
            if(ret == -1){
                throw new SQLiteException();
            }
        }catch (SQLException e){
            e.printStackTrace();
            Log.e("CardSQLiteOpenHelper", "削除処理でエラーが起きました");
        }finally {
            db.close();
        }

    }

    public Card findCardById(int id){
        Card tmp = null;
        SQLiteDatabase db = getReadableDatabase();
        try{
            String sid = String.valueOf(id);
            String[] column = new String[]{"japanese", "english", "_id"};
            Cursor cur = db.query("CARD", column, "_id=?", new String[]{sid}, null, null, null);
            if(cur.moveToNext()){
                tmp = new Card(cur.getString(0), cur.getString(1), cur.getInt(2));
            }
            cur.close();
        }finally{
            db.close();
        }
        return tmp;
    }

    /**
     * _id指定で
     * @param newCard
     * @return
     */
    public boolean updateCard(Card newCard) {
        long ret ;
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("english", newCard.getEnglish());
            values.put("japanese", newCard.getJapanese());
            String sid = String.valueOf(newCard.getId());
            ret = db.update("CARD", values, "_id=?", new String[]{sid});
        } finally {
            db.close();
        }
        return ret != -1;//TRUE:成功、　FALSE:失敗
    }


}