package jp.ac.jec.cm0111.android114;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CardActivity extends AppCompatActivity {

    private ArrayList<Card> ary = new ArrayList<Card>(); //複数のカード情報
    private int pos;  //現在表示しているカードの位置

    private Button btnNext;
    private Button btnPrev;
    private Button btnAnswer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        //各種
        btnNext = (Button)findViewById(R.id.btnNext);
        btnPrev = (Button)findViewById(R.id.btnPrev);
        btnNext.setEnabled(true);
        btnPrev.setEnabled(false);
        btnAnswer = (Button)findViewById(R.id.btnAnswer);

        //表示インデックスの初期化
        pos = 0;

        //データベースからカード情報を取得する
        CardSQLiteOpenHelper helper = new CardSQLiteOpenHelper(this);
        ary = helper.getAllCard();

        //TODO カードデータを表示する
        dispOneCard();

        Toast.makeText(CardActivity.this,"最初のカードです",Toast.LENGTH_SHORT).show();

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos++;
                if(pos == ary.size()){
                    return;
                }
                btnNext.setEnabled(true);
                btnPrev.setEnabled(true);

                if(pos == ary.size() - 1){
                    btnNext.setEnabled(false);
                    Toast.makeText(CardActivity.this,"お疲れ様でした!",Toast.LENGTH_SHORT).show();
                }

                dispOneCard();
            }
        });

        //TODO PREVボタンの実装


        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos--;
                btnNext.setEnabled(true);
                if(pos == -1){
                    return;
                }
                btnNext.setEnabled(true);
                btnPrev.setEnabled(true);
                if(pos == 0){
                    btnPrev.setEnabled(false);
                    Toast.makeText(CardActivity.this,"最初のカードです",Toast.LENGTH_SHORT).show();
                }
                dispOneCard();
            }


        });

        btnAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView txtJapanese = (TextView)findViewById(R.id.txtJapanese);

                if(txtJapanese.getVisibility() == View.VISIBLE){
                    txtJapanese.setVisibility(View.INVISIBLE);
                }else {
                    txtJapanese.setVisibility(View.VISIBLE);
                }
            }
        });

    }

    /**
     * カードデータを表示する処理のメソッド
     */

    private void dispOneCard(){
        Card tmp = ary.get(pos); //現在位置のカード情報を取得する
        TextView txt1 = (TextView)findViewById(R.id.txtEnglish);
        txt1.setText(tmp.getEnglish());  //英語を表示させる
        TextView txt2 = (TextView)findViewById(R.id.txtJapanese);
        txt2.setText(tmp.getJapanese()); //日本語を表示させる
        txt2.setVisibility(View.INVISIBLE); //初期状態では日本語を非表示にする

        //問題番号を表示する
        TextView txtNum = (TextView)findViewById(R.id.txtQuestionNum);
        txtNum.setText("第" + (pos + 1) + "問");
    }


}



