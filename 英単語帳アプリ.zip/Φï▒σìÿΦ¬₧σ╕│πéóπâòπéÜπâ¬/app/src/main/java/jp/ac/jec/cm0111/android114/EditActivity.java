package jp.ac.jec.cm0111.android114;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;


import java.util.ArrayList;

public class EditActivity extends AppCompatActivity {

    private int id = -1; //今現在表示しているカードのID


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);


        Intent intent = getIntent();
        String mode = intent.getStringExtra("mode");

        if("update".equals(mode)){
            id = intent.getIntExtra("id", -1);

            //idを指定してCard情報を取得する
            CardSQLiteOpenHelper helper = new CardSQLiteOpenHelper(this);
            Card tmp = helper.findCardById(id);

            //Card情報からそれぞれ英語、日本語を取り出し、該当のEditTextにセットしておく
            EditText edtEnglish = (EditText)findViewById(R.id.edtEnglish);
            edtEnglish.setText(tmp.getEnglish());

            EditText edtJapanese = (EditText)findViewById(R.id.edtJapanese);
            edtJapanese.setText(tmp.getJapanese());

            //TODO 削除ボタンを動的に生成しよう
            LinearLayout lay = (LinearLayout)findViewById(R.id.layEditHome);
            Button newBtn = new Button(this);//ボタンのインスタンスを生成

            newBtn.setOnClickListener(new DeleteOnClickAction());
            newBtn.setText("DELETE");
            newBtn.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));

            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) newBtn.getLayoutParams();
            lp.setMargins(50,0,50,0);
            newBtn.setLayoutParams(lp);
            //ボタンの幅をmatch_parent,高さをwrap_contentにする
            lay.addView(newBtn);//上位のレイアウトに追加する
        }


        Button btnAdd = (Button)findViewById(R.id.btnAdd);
        if("update".equals(mode)){
            btnAdd.setOnClickListener(new UpdateOnClickAction());//編集用のイベントリスナを設定する
            btnAdd.setText("UPDATE");//ボタン文字を「UPDATE」に変える
        }else { //モードがAddの場合
            btnAdd.setOnClickListener(new AddOnClickAction());
            btnAdd.setText("ADD");
        }

        Button btnClose = (Button) findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private class DeleteOnClickAction implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            AlertDialog.Builder builder = new AlertDialog.Builder(EditActivity.this);
            builder.setTitle("削除");
            builder.setMessage("本当に削除しますか？");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    CardSQLiteOpenHelper helper = new CardSQLiteOpenHelper(EditActivity.this);
                    helper.deleteCardById(id);

                    Intent intent = new Intent(EditActivity.this, CardListActivity.class);
                    startActivity(intent);

                    Toast.makeText(EditActivity.this, "削除しました", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    return;
                }
            });
            builder.show();
        }
    }

        private class AddOnClickAction implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            EditText edtE = (EditText)findViewById(R.id.edtEnglish);
            EditText edtJ = (EditText)findViewById(R.id.edtJapanese);
            String english = edtE.getText().toString();
            String japanese = edtJ.getText().toString();

            if(english.equals("") || japanese.equals("")) {
                Toast.makeText(EditActivity.this,"単語データを入力してください", Toast.LENGTH_SHORT).show();
                return;
            }

            CardSQLiteOpenHelper helper = new CardSQLiteOpenHelper(EditActivity.this);

            if(helper.isExistWord(english)){
                Toast.makeText(EditActivity.this, "すでに存在している単語です",Toast.LENGTH_SHORT).show();
                return;
            }

            Card newCard = new Card(japanese, english, -1);

            boolean ret = helper.insertCard(newCard);
            if( ret ){
                Toast.makeText(EditActivity.this,"追加成功!", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(EditActivity.this, "追加失敗！", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private class UpdateOnClickAction implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            EditText edtE = (EditText) findViewById(R.id.edtEnglish);
            EditText edtJ = (EditText) findViewById(R.id.edtJapanese);
            String english = edtE.getText().toString();
            String japanese = edtJ.getText().toString();

            if(english.equals("") || japanese.equals("")) {
                Toast.makeText(EditActivity.this,"単語データを入力してください", Toast.LENGTH_SHORT).show();
                return;
            }

            CardSQLiteOpenHelper helper = new CardSQLiteOpenHelper(EditActivity.this);


            if(helper.isExistWord(english)){
                Toast.makeText(EditActivity.this, "すでに存在している単語です",Toast.LENGTH_SHORT).show();
                return;
            }

            Card newCard = new Card(japanese, english, id);


            boolean ret = helper.updateCard(newCard);
            if (ret) {
                Toast.makeText(EditActivity.this, "編集成功!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(EditActivity.this, "編集失敗！", Toast.LENGTH_SHORT).show();

            }
        }


    }

}
